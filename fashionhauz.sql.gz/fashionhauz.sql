-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2024 at 07:26 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fashionhauz`
--

-- --------------------------------------------------------

--
-- Table structure for table `activitylogs`
--

CREATE TABLE `activitylogs` (
  `id` int(11) NOT NULL,
  `uname` varchar(150) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activitylogs`
--

INSERT INTO `activitylogs` (`id`, `uname`, `description`, `date_created`) VALUES
(1, 'admin', 'Added product: Assorted Bangles', '2024-11-24 09:37:38'),
(2, 'admin', 'New Gold size for Assorted Bangles', '2024-11-24 09:37:58'),
(3, 'admin', 'New Black size for Assorted Bangles', '2024-11-24 09:38:26'),
(4, 'admin', 'New Silver size for Assorted Bangles', '2024-11-24 09:38:37'),
(5, 'admin', 'Added product: Gold Necklace', '2024-11-24 09:42:09'),
(6, 'admin', 'New 16\" size for Gold Necklace', '2024-11-24 09:43:42'),
(7, 'admin', 'New 18\" size for Gold Necklace', '2024-11-24 09:43:57'),
(8, 'admin', 'New 20\" size for Gold Necklace', '2024-11-24 09:44:17'),
(9, 'admin', 'Logged out', '2024-11-24 09:45:37'),
(10, 'admin', 'Logged in', '2024-11-24 09:52:03'),
(11, 'admin', 'Updated product: Gold Necklace in size 16\'', '2024-11-24 09:52:34'),
(12, 'admin', 'Updated product: Gold Necklace in size 18\'', '2024-11-24 09:52:50'),
(13, 'admin', 'Updated product: Gold Necklace in size 20\'', '2024-11-24 09:53:00'),
(14, 'admin', 'Logged out', '2024-11-24 09:53:07'),
(15, 'admin', 'Logged in', '2024-11-26 12:52:21'),
(16, 'admin', 'Logged out', '2024-12-03 04:54:31'),
(17, 'admin', 'Logged in', '2024-12-03 05:14:45'),
(18, 'admin', 'Logged out', '2024-12-03 05:21:21'),
(19, 'admin', 'Logged in', '2024-12-03 05:22:42'),
(20, 'admin', 'Logged out', '2024-12-03 05:23:11'),
(21, 'admin', 'Logged in', '2024-12-03 05:23:57'),
(22, 'admin', 'Logged out', '2024-12-03 05:29:38'),
(23, 'admin', 'Logged in', '2024-12-03 05:35:01'),
(24, 'admin', 'Added employee username: qwer', '2024-12-03 05:40:06'),
(25, 'admin', 'Account qwer was updated', '2024-12-03 05:40:29'),
(26, 'admin', 'Deleted user: qwer', '2024-12-03 05:44:21'),
(27, 'admin', 'Logged out', '2024-12-07 11:42:19'),
(28, 'admin', 'Logged in', '2024-12-08 03:38:20'),
(29, 'admin', 'Added employee username: qwer', '2024-12-08 03:38:56'),
(30, 'admin', 'Deleted user: qwer', '2024-12-08 03:39:00'),
(31, 'admin', 'Logged out', '2024-12-08 03:40:40'),
(32, 'admin', 'Logged in', '2024-12-08 04:22:33'),
(33, 'admin', 'Logged in', '2024-12-11 04:20:08'),
(34, 'admin', 'Logged in', '2024-12-11 04:40:07'),
(35, 'admin', 'Logged in', '2024-12-11 04:44:53'),
(36, 'admin', 'Logged in', '2024-12-11 04:55:27'),
(37, 'admin', 'Logged in', '2024-12-11 05:02:38'),
(38, 'admin', 'Logged out', '2024-12-11 05:04:48'),
(39, 'admin', 'Logged in', '2024-12-11 05:11:28'),
(40, 'admin', 'Logged in', '2024-12-11 05:17:15'),
(41, 'admin', 'Logged in', '2024-12-11 05:24:41'),
(42, 'admin', 'Logged in', '2024-12-11 05:28:06'),
(43, 'admin', 'New Banner: banner.jpg', '2024-12-11 05:44:06'),
(44, 'admin', 'New Banner: bg.jpg', '2024-12-11 05:45:18'),
(45, 'admin', 'New Banner: bg.png', '2024-12-11 05:46:10'),
(46, 'admin', 'Logged out', '2024-12-11 05:46:14'),
(47, 'admin', 'Logged in', '2024-12-11 05:50:23'),
(48, 'admin', 'New Banner: banner.jpg', '2024-12-11 05:50:30'),
(49, 'admin', 'Logged out', '2024-12-11 05:50:32');

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `cnumber` varchar(15) NOT NULL,
  `street` varchar(150) NOT NULL,
  `barangay` varchar(150) NOT NULL,
  `city` varchar(150) NOT NULL,
  `province` varchar(150) NOT NULL,
  `region` varchar(5) NOT NULL,
  `postal` int(5) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `userID`, `name`, `cnumber`, `street`, `barangay`, `city`, `province`, `region`, `postal`, `status`, `date_created`) VALUES
(5, 9, 'Ramon Rius', '09123123123', 'cristina village', 'Sipat', 'Plaridel', 'Bulacan', 'III', 5678, 'inactive', '2024-12-08 03:26:40'),
(6, 9, 'Ramon Rius', '09123123123', 'asdasdas', 'Sipat', 'Plaridel', 'Bulacan', 'III', 4768, 'active', '2024-12-08 03:31:07');

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `banner` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `banner`, `date_created`) VALUES
(1, 'banner.jpg', '2024-12-11 05:44:06');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `prodname` varchar(250) NOT NULL,
  `size` varchar(250) NOT NULL,
  `price` double(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `usercateg` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category` varchar(250) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category`, `date_created`) VALUES
(1, 'Watch', '2024-10-16 08:37:39'),
(3, 'Earrings', '2024-10-17 09:32:35'),
(4, 'Bangles', '2024-10-24 07:19:40'),
(5, 'Rings', '2024-10-24 07:19:48'),
(6, 'Necklace', '2024-10-24 07:19:55');

-- --------------------------------------------------------

--
-- Table structure for table `orderlist`
--

CREATE TABLE `orderlist` (
  `orderID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `total_qty` int(10) NOT NULL,
  `mop` varchar(250) NOT NULL,
  `total_price` double(10,2) NOT NULL,
  `address_id` int(11) DEFAULT NULL,
  `status` varchar(250) NOT NULL,
  `tracking` varchar(20) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderlist`
--

INSERT INTO `orderlist` (`orderID`, `userID`, `total_qty`, `mop`, `total_price`, `address_id`, `status`, `tracking`, `date_created`) VALUES
(1, 9, 2, 'use case.png', 445.00, 4, 'Pending', '', '2024-12-07 12:13:37'),
(2, 9, 2, 'qr.jpg', 430.00, 6, 'Pending', '', '2024-12-08 03:31:48'),
(3, 9, 2, 'qr.jpg', 310.00, 6, 'Pending', '', '2024-12-08 03:33:40'),
(4, 9, 1, 'lvl 2.2.jpg', 190.00, 6, 'Pending', '', '2024-12-11 05:05:07');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `orderID` int(11) NOT NULL,
  `prodID` int(11) NOT NULL,
  `sizeID` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` double(10,2) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`orderID`, `prodID`, `sizeID`, `qty`, `price`, `date_created`) VALUES
(1, 17, 20, 1, 170.00, '2024-12-07 12:13:37'),
(1, 17, 21, 1, 190.00, '2024-12-07 12:13:37'),
(2, 17, 20, 1, 170.00, '2024-12-08 03:31:48'),
(2, 17, 21, 1, 190.00, '2024-12-08 03:31:48'),
(3, 16, 16, 1, 120.00, '2024-12-08 03:33:40'),
(3, 16, 17, 1, 120.00, '2024-12-08 03:33:40'),
(4, 16, 16, 1, 120.00, '2024-12-11 05:05:07');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(50) NOT NULL,
  `prodname` varchar(150) NOT NULL,
  `description` varchar(200) NOT NULL,
  `category` varchar(50) NOT NULL,
  `image` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `prodname`, `description`, `category`, `image`, `date_created`) VALUES
(14, 'Swiss Watch', 'Japan made swiss machine watch matched with stainless strap.', 'Watch', 'swisswatch.jpg', '2024-11-24 09:25:11'),
(15, 'Assorted Rings', 'Japan made assorted rings made with plated gold.', 'Rings', '460039027_851994353742165_2678411199551802700_n.jpg', '2024-11-24 09:26:14'),
(16, 'Assorted Bangles', 'Japan made bangles fit for every fashion ideas.', 'Bangles', '460091969_1913086565838392_5703233708446008061_n.jpg', '2024-11-24 09:37:38'),
(17, 'Gold Necklace', 'Hypoallergenic tarnish resistant necklace made from gold.', 'Necklace', '461537618_1046720043383728_8720735149927101508_n.jpg', '2024-11-24 09:42:09');

-- --------------------------------------------------------

--
-- Table structure for table `product_sizes`
--

CREATE TABLE `product_sizes` (
  `size_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `size` varchar(250) NOT NULL,
  `qty` int(10) NOT NULL,
  `price` double(10,2) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_sizes`
--

INSERT INTO `product_sizes` (`size_id`, `id`, `size`, `qty`, `price`, `date_created`) VALUES
(10, 15, '16', 10, 50.00, '2024-11-24 09:26:48'),
(11, 15, '17', 10, 50.00, '2024-11-24 09:27:07'),
(12, 15, '18', 10, 60.00, '2024-11-24 09:27:18'),
(13, 14, '28mm', 10, 250.00, '2024-11-24 09:30:50'),
(14, 14, '32mm', 10, 280.00, '2024-11-24 09:31:26'),
(15, 14, '36mm', 10, 300.00, '2024-11-24 09:31:53'),
(16, 16, 'Gold', 10, 120.00, '2024-11-24 09:37:58'),
(17, 16, 'Black', 10, 120.00, '2024-11-24 09:38:26'),
(18, 16, 'Silver', 10, 120.00, '2024-11-24 09:38:37'),
(19, 17, '16\'', 12, 150.00, '2024-11-24 09:43:42'),
(20, 17, '18\'', 10, 170.00, '2024-11-24 09:43:57'),
(21, 17, '20\'', 10, 190.00, '2024-11-24 09:44:17');

-- --------------------------------------------------------

--
-- Table structure for table `security`
--

CREATE TABLE `security` (
  `userID` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `security`
--

INSERT INTO `security` (`userID`, `question`, `answer`) VALUES
(1, 'What is your favorite color for accessories?', 'red'),
(9, 'What was the first accessory you ever received as a gift?', 'watch');

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE `subscription` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `age` int(3) NOT NULL,
  `bday` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `cnumber` varchar(20) NOT NULL,
  `email` varchar(250) NOT NULL,
  `uname` varchar(150) NOT NULL,
  `pword` varchar(150) NOT NULL,
  `category` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `fname`, `mname`, `lname`, `age`, `bday`, `gender`, `cnumber`, `email`, `uname`, `pword`, `category`, `status`, `date_created`) VALUES
(1, '', '', '', 0, '0000-00-00', '', '', 'admin@gmail.com', 'admin', '$2y$10$YL6B6v3QwA.lKuEtKF/oB.g47PAxhzwdVPm2HULGZADs6l7c1.6wq', 'admin', 'active', '2024-11-24 09:34:47'),
(9, '', '', '', 0, '0000-00-00', '', '', 'rmnrius@gmail.com', 'amon', '$2y$10$Vh3RhoqEVFr5jxvUFHtvIuIQKYtx2WvyZyOe8Hcp8WXbUpe87y/kS', 'customer', 'active', '2024-12-07 11:49:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activitylogs`
--
ALTER TABLE `activitylogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uname` (`uname`);

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `addressToUser` (`userID`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prodname` (`prodname`),
  ADD KEY `usercateg` (`usercateg`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderlist`
--
ALTER TABLE `orderlist`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `userToOrder` (`userID`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`orderID`,`prodID`,`sizeID`),
  ADD KEY `orderID` (`orderID`,`sizeID`),
  ADD KEY `const_prodid` (`prodID`),
  ADD KEY `const_prodsize` (`sizeID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `prodname` (`prodname`);

--
-- Indexes for table `product_sizes`
--
ALTER TABLE `product_sizes`
  ADD PRIMARY KEY (`size_id`),
  ADD KEY `prodsize` (`id`);

--
-- Indexes for table `security`
--
ALTER TABLE `security`
  ADD KEY `secuToUser` (`userID`);

--
-- Indexes for table `subscription`
--
ALTER TABLE `subscription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `uname` (`uname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activitylogs`
--
ALTER TABLE `activitylogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `product_sizes`
--
ALTER TABLE `product_sizes`
  MODIFY `size_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `subscription`
--
ALTER TABLE `subscription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activitylogs`
--
ALTER TABLE `activitylogs`
  ADD CONSTRAINT `ibfk_uname_users` FOREIGN KEY (`uname`) REFERENCES `users` (`uname`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `addressToUser` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `ibfk_cart_proddetails` FOREIGN KEY (`prodname`) REFERENCES `products` (`prodname`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orderlist`
--
ALTER TABLE `orderlist`
  ADD CONSTRAINT `userToOrder` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `const_orderid` FOREIGN KEY (`orderID`) REFERENCES `orderlist` (`orderID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `const_prodid` FOREIGN KEY (`prodID`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `const_prodsize` FOREIGN KEY (`sizeID`) REFERENCES `product_sizes` (`size_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_sizes`
--
ALTER TABLE `product_sizes`
  ADD CONSTRAINT `prodsize` FOREIGN KEY (`id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `security`
--
ALTER TABLE `security`
  ADD CONSTRAINT `secuToUser` FOREIGN KEY (`userID`) REFERENCES `users` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
